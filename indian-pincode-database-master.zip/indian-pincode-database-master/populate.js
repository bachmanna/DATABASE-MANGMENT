// simple example of population
const indianPincodeDatabase = require('./');
indianPincodeDatabase.pushToDatabase('pincodeDb', 'pincodes');